package com.hunterstraductor.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var translatorPlEs: Translator
    private lateinit var translatorEsPl: Translator
    private var tts: TextToSpeech? = null
    private var listeningPolish = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        translatorPlEs = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.POLISH)
                .setTargetLanguage(TranslateLanguage.SPANISH).build()
        )
        translatorEsPl = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.SPANISH)
                .setTargetLanguage(TranslateLanguage.POLISH).build()
        )
        buildUi()
        requestPermissionsIfNeeded()
        downloadModels()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "Hunters Traductor\n🇵🇱  POLACO  ↔  ESPAÑOL  🇪🇸"
            textSize = 23f
            gravity = Gravity.CENTER
        }
        input = EditText(this).apply {
            hint = "Escribe o dicta el texto aquí"
            minLines = 3
            textSize = 18f
        }
        val direction = Button(this).apply {
            text = "Traducir polaco → español"
            setOnClickListener { translate() }
        }
        val switch = Button(this).apply {
            text = "Cambiar dirección"
            setOnClickListener {
                listeningPolish = !listeningPolish
                direction.text = if (listeningPolish) "Traducir polaco → español" else "Traducir español → polaco"
            }
        }
        val mic = Button(this).apply {
            text = "🎙 Dictar por voz"
            setOnClickListener { startListening() }
        }
        output = TextView(this).apply {
            text = "La traducción aparecerá aquí."
            textSize = 20f
            setPadding(8, 24, 8, 24)
        }
        val speak = Button(this).apply {
            text = "🔊 Escuchar traducción"
            setOnClickListener {
                val lang = if (listeningPolish) Locale("es", "ES") else Locale("pl", "PL")
                tts?.language = lang
                tts?.speak(output.text.toString(), TextToSpeech.QUEUE_FLUSH, null, "hunters_translation")
            }
        }
        root.addView(title)
        root.addView(input, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(direction)
        root.addView(switch)
        root.addView(mic)
        root.addView(output)
        root.addView(speak)
        setContentView(root)
    }

    private fun downloadModels() {
        val conditions = DownloadConditions.Builder().build()
        translatorPlEs.downloadModelIfNeeded(conditions)
        translatorEsPl.downloadModelIfNeeded(conditions)
    }

    private fun translate() {
        val source = input.text.toString().trim()
        if (source.isEmpty()) { input.error = "Escribe un texto"; return }
        val translator = if (listeningPolish) translatorPlEs else translatorEsPl
        output.text = "Traduciendo…"
        translator.translate(source)
            .addOnSuccessListener { output.text = it }
            .addOnFailureListener { output.text = "No se pudo traducir. Comprueba Internet y descarga los modelos." }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            output.text = "El reconocimiento de voz no está disponible en este teléfono."
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (listeningPolish) "pl-PL" else "es-ES")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla ahora")
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, 701)
        } catch (_: Exception) {
            output.text = "No se pudo iniciar el micrófono."
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 701 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) { input.setText(spoken); translate() }
        }
    }

    private fun requestPermissionsIfNeeded() {
        val wanted = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (android.os.Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED)
            wanted.add(Manifest.permission.RECEIVE_SMS)
        ActivityCompat.requestPermissions(this, wanted.toTypedArray(), 44)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("es", "ES")
    }

    override fun onDestroy() {
        translatorPlEs.close()
        translatorEsPl.close()
        tts?.shutdown()
        super.onDestroy()
    }
}
