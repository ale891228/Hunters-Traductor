package com.hunterstraductor.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*

class IncomingSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val body = messages.joinToString("") { it.messageBody ?: "" }
        if (body.isBlank()) return

        val pending = goAsync()
        val translator = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.POLISH)
                .setTargetLanguage(TranslateLanguage.SPANISH).build()
        )
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                translator.translate(body)
                    .addOnSuccessListener { translated ->
                        showNotification(context, body, translated)
                        translator.close()
                        pending.finish()
                    }
                    .addOnFailureListener {
                        showNotification(context, body, "No se pudo traducir. Texto original: $body")
                        translator.close()
                        pending.finish()
                    }
            }
            .addOnFailureListener {
                showNotification(context, body, "Conéctate a Internet para descargar el modelo. Original: $body")
                translator.close()
                pending.finish()
            }
    }

    private fun showNotification(context: Context, original: String, translated: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = "hunters_sms"
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channel, "SMS traducidos", NotificationManager.IMPORTANCE_HIGH))
        }
        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("Hunters Traductor · SMS recibido")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Traducción: $translated\n\nOriginal: $original"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
