# Hunters Traductor

Proyecto Android inicial para Samsung Galaxy A55 5G.

## Funciones incluidas en esta primera base
- Traducción manual Polaco → Español y Español → Polaco.
- Descarga de modelos de traducción ML Kit para uso posterior sin conexión.
- Dictado de texto mediante el servicio de reconocimiento de voz instalado en Android.
- Lectura de SMS entrantes mediante permiso RECEIVE_SMS y aviso con traducción Polaco → Español.

## Limitaciones importantes
- El reconocimiento de voz sin conexión depende del motor de voz instalado y de que tenga descargados los idiomas polaco y español.
- La recepción de SMS puede estar sujeta a permisos, restricciones de Android y políticas de distribución. Para publicar en Google Play, la app debe cumplir las políticas de SMS.
- Esta base NO intercepta el audio de llamadas telefónicas ni de WhatsApp. Android normalmente no permite a una app ordinaria capturar el audio remoto de esas llamadas. El modo intérprete por micrófono/altavoz deberá utilizarse como alternativa, con consentimiento de las personas.
- No se envían SMS automáticamente ni se responde sin confirmación del usuario.

## Compilar
Abrir la carpeta en Android Studio (Giraffe o posterior), permitir que Gradle descargue dependencias y elegir Build > Build Bundle(s) / APK(s) > Build APK(s).

Requisitos: Android Studio, Android SDK 35 y conexión a Internet durante la primera compilación y descarga de modelos.

## Compilación en la nube sin Windows
El repositorio incluye `.github/workflows/android.yml`. Si subes esta carpeta a un repositorio GitHub y ejecutas la acción **Build Hunters Traductor APK**, GitHub Actions compilará el APK y lo publicará como artefacto descargable en la ejecución. Esto requiere una cuenta GitHub y conexión a Internet; no requiere instalar Android Studio en tu teléfono u ordenador.
